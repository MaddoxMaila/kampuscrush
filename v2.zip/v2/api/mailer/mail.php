<?php



require_once('../framework/db/query.php');



  class Mailer extends Query{

  	function __construct(){

  		parent::__construct();

  	} # End Of Constructor

  } # End Of Class


?>